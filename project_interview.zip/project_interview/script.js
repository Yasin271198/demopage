function selectOption(price) {
  // Update the total price when a radio button is clicked
  document.getElementById('total').textContent = `$${price}.00 USD`;
}